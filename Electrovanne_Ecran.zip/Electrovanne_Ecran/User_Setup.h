#define TFT_MISO 19
#define TFT_MOSI 23
#define TFT_SCLK 18
#define TFT_CS   15
#define TFT_DC   5
#define TFT_RST  4
#define TFT_BL   13
#define TFT_BACKLIGHT_ON HIGH